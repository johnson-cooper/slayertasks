package me.fourdivision.slayertasks;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class slayertasks extends JavaPlugin implements Listener {
    private final Random random = new Random();
    private final Map<Player, Quest> activeQuests = new HashMap<>();
    private final Set<Player> taskInProgress = new HashSet<>(); // Tracks players with active tasks
    private Economy economy;
    private FileConfiguration config;
    private boolean taskInProgressEnabled; // Flag to indicate if the task in progress feature is enabled

    @Override
    public void onEnable() {
        if (!setupEconomy()) {
            getLogger().warning("Vault not found. Disabling money rewards.");
        }

        config = getConfig();
        config.options().copyDefaults(true);
        saveConfig();
        taskInProgressEnabled = config.getBoolean("taskInProgressEnabled", true); // Read the value from config

        getServer().getPluginManager().registerEvents(this, this);
    }

    private boolean setupEconomy() {
        if (getServer().getPluginManager().getPlugin("Vault") == null) {
            return false;
        }

        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) {
            return false;
        }

        economy = rsp.getProvider();
        return true;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("Only players can execute this command.");
            return true;
        }

        Player player = (Player) sender;

        if (label.equalsIgnoreCase("slayer")) {
            if (player.hasPermission("slayertasks.slayer")) {
                if (taskInProgress.contains(player)) {
                    player.sendMessage("You already have an active task. Complete it before starting a new one.");
                } else {
                    openQuestsChest(player);
                }
            } else {
                player.sendMessage("You do not have permission to use this command.");
            }
        } else if (label.equalsIgnoreCase("skc")) {
            if (player.hasPermission("slayertasks.skc")) {
                displayQuestProgress(player);
            } else {
                player.sendMessage("You do not have permission to use this command.");
            }
        }

        return true;
    }

    private void openQuestsChest(Player player) {
        Inventory inventory = Bukkit.createInventory(player, 9, "Slayer");

        populateQuestSlot(inventory, 0, "Easy");
        populateQuestSlot(inventory, 1, "Medium");
        populateQuestSlot(inventory, 2, "Hard");
        populateQuestSlot(inventory, 3, "Insane");

        player.openInventory(inventory);
    }

    private void populateQuestSlot(Inventory inventory, int slot, String swordName) {
        Material swordMaterial;
        switch (swordName) {
            case "Easy":
                swordMaterial = Material.WOOD_SWORD;
                break;
            case "Medium":
                swordMaterial = Material.STONE_SWORD;
                break;
            case "Hard":
                swordMaterial = Material.IRON_SWORD;
                break;
            case "Insane":
                swordMaterial = Material.DIAMOND_SWORD;
                break;
            default:
                swordMaterial = Material.GOLD_SWORD;
                break;
        }

        ItemStack sword = new ItemStack(swordMaterial);
        ItemMeta swordMeta = sword.getItemMeta();
        swordMeta.setDisplayName(swordName);
        sword.setItemMeta(swordMeta);
        inventory.setItem(slot, sword);
    }

    private void displayQuestProgress(Player player) {
        if (activeQuests.containsKey(player)) {
            Quest quest = activeQuests.get(player);
            player.sendMessage("You have killed " + quest.getKills() + " out of " + quest.getAmount() + " " + quest.getMob() + "(s).");
        } else {
            player.sendMessage("You currently don't have an active task.");
        }
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (event.getView().getTitle().equals("Slayer")) {
            event.setCancelled(true);
            ItemStack clickedItem = event.getCurrentItem();
            if (clickedItem != null && clickedItem.hasItemMeta()) {
                Player player = (Player) event.getWhoClicked();
                String questName = clickedItem.getItemMeta().getDisplayName();
                if (!taskInProgress.contains(player) || !taskInProgressEnabled) { // Check if the feature is enabled
                    setQuest(player, questName);
                    if (taskInProgressEnabled) {
                        taskInProgress.add(player); // Set the flag to indicate an active task
                    }
                    player.closeInventory();
                } else {
                    player.sendMessage("You already have an active task. Complete it before starting a new one.");
                }
            }
        }
    }

    @EventHandler
    public void onEntityDeath(EntityDeathEvent event) {
        LivingEntity entity = event.getEntity();
        if (entity.getKiller() instanceof Player) {
            Player player = (Player) entity.getKiller();
            if (activeQuests.containsKey(player)) {
                Quest quest = activeQuests.get(player);
                EntityType entityType = entity.getType();
                if (entityType.toString().equals(quest.getMob())) {
                    quest.incrementKills();
                    player.sendMessage("[Task] You killed " + quest.getKills() + " out of " + quest.getAmount() + " " + quest.getMob() + "(s)");
                    if (quest.isCompleted()) {
                        double reward = calculateReward(quest.getAmount());
                        player.sendMessage("[Task] You completed the task and earned $" + reward);
                        if (economy != null) {
                            economy.depositPlayer(player, reward);
                        }
                        activeQuests.remove(player);
                        taskInProgress.remove(player); // Remove the flag to indicate completion of the task
                    }
                }
            }
        }
    }

    private void setQuest(Player player, String questName) {
        String mob = getRandomElement(getMobListFromConfig());
        double amountMultiplier = getConfig().getDouble("mobAmountMultiplier", 1.0); // Retrieve the multiplier value
        int amount;

        switch (questName) {
            case "Easy":
                amount = (int) Math.round((random.nextInt(5) + 1) * amountMultiplier); // Apply the multiplier to the amount
                break;
            case "Medium":
                amount = (int) Math.round((random.nextInt(10) + 6) * amountMultiplier);
                break;
            case "Hard":
                amount = (int) Math.round((random.nextInt(15) + 16) * amountMultiplier);
                break;
            case "Insane":
                amount = (int) Math.round((random.nextInt(20) + 31) * amountMultiplier);
                break;
            default:
                amount = (int) Math.round((random.nextInt(10) + 1) * amountMultiplier);
                break;
        }

        Quest quest = new Quest(mob, amount, 0);
        activeQuests.put(player, quest);
        player.sendMessage("Your task is to kill " + amount + " " + mob + "(s).");
    }

    private List<String> getMobListFromConfig() {
        return config.getStringList("mobList");
    }

    private String getRandomElement(List<String> list) {
        return list.get(random.nextInt(list.size()));
    }

    private double calculateReward(int questAmount) {
        double rewardMultiplier = getConfig().getDouble("rewardMultiplier", 1.0);
        double amountMultiplier = getConfig().getDouble("mobAmountMultiplier", 1.0);
        return questAmount * 10.0 * rewardMultiplier * amountMultiplier; // Apply the multiplier to the reward calculation
    }

    private static class Quest {
        private final String mob;
        private final int amount;
        private int kills;

        public Quest(String mob, int amount, int kills) {
            this.mob = mob;
            this.amount = amount;
            this.kills = kills;
        }

        public String getMob() {
            return mob;
        }

        public int getAmount() {
            return amount;
        }

        public int getKills() {
            return kills;
        }

        public void incrementKills() {
            kills++;
        }

        public boolean isCompleted() {
            return kills >= amount;
        }
    }
}